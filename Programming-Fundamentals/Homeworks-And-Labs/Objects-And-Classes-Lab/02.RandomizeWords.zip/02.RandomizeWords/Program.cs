﻿using System;
using System.Linq;

namespace _02.RandomizeWords
{
    class Program
    {
        static void Main(string[] args)
        {
            Randomizer resul = new Randomizer();
            resul.words = Console.ReadLine().Split().ToList();
            resul.RandomizerWords();
            resul.PrintWords();
        }
    }
}
